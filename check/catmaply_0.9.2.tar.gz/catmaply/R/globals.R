utils::globalVariables(c("col_palette", "%>%", ".data"))
