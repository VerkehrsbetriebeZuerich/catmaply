# catmaply 0.9.2 (20 Sept 2021)
* added pkgdown
* minor cleaning to fix HTML validation errors
* removed unnecessary imports.
* added additional remote

# catmaply 0.9.1 (12 Aug 2021)
* Maintenance (added rmarkdown to Suggests)

## catmaply 0.9.0 (31 Aug 2020)
* Simple categorical heatmap
* Color ranges per category
* Axis formatting
* Hover templating
* Time Axis
* Slider
* Annotations
